







#include<stdio.h> 
  int largestPalindrome(int n) 
{ 
    int upper_limit = 0;
	int i; 
      for (i = 1; i <= n; i++) 
    { 
        upper_limit *= 10;    upper_limit += 9; 
    }
    int lower_limit = 1 + upper_limit / 10; 
  
    int max_product = 0;
  
    for (i = upper_limit;  
             i >= lower_limit;  
             i--) 
    { int j;
        for (j = i; j >= lower_limit; j--) 
        { 
          
            int product = i * j; 
            if (product < max_product) 
                break; 
            int value = product; 
            int reverse = 0; 
  
            
            while (value != 0) 
            { 
                reverse = reverse * 10 +  
                          value % 10; 
               value /= 10; 
            } 
  
            if (product == reverse &&  
                product > max_product) 
                  
                max_product = product; 
        } 
    } 
    return max_product; 

} 
 
int main() 
{ 
    int s = 2; 
    int k = 3;  int p;  int m;
    p = largestPalindrome(s);
    m = largestPalindrome(k);
    printf("\nThe largest palindrome with two  digit is: %d",p); 
    printf("\nThe largest palindrome with three digit is: %d",m);
    return 0; 
} 

