#include<stdio.h>
int main()
{
	char line[30];
        ("\nEnter an input\n");
        scanf("%s",line);
        int input;
	input = atoi(line);
	printf("\nThe integer entered %d\n",input);
	return 0;
}
