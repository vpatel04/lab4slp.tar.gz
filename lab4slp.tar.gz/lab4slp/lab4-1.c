#include<stdio.h>
int main()
{

       		char in[100];
                printf("Enter a line: \n");
      		scanf("%s",in);
		printf("You entered: %s",in);
		return 0;
}
