#include<stdio.h>

char* num_to_words_ones(char c)
{
        
        char const *word;
        if(c=='0')
                word = "Zero";
        if(c=='1')
                word = "One";
        if(c=='2')
                word = "Two";
        if(c=='3')
                word = "Three";
        if(c=='4')
                word = "Four";
        if(c=='5')
                word = "Five";
        if(c=='6')
                word = "Six";
        if(c=='7')
                word = "Seven";
        if(c=='8')
                word = "Eight";
        if(c=='9')
                word = "Nine";
        return (char *)word;                    
}
int main()
  {

char numchar[3];
        printf("\n Enter the integer to convert into string: ");
        scanf("%s",numchar);
        
        if(numchar[2]!='\0')
        {
                printf("\n Input Integer should be less than 100.");
        }
        else
        {
                if(numchar[1]=='\0') 
                {
                        char n = numchar[0];
                        printf("%s",num_to_words_ones(n));
                }
                else 
                {
                        char n1 = numchar[0];
                        char n2 = numchar[1];
                        if(n1=='0')
                        {
                                printf("%s",num_to_words_ones(n2));
                        }
                        if(n1=='1')
                        {
                                if(n2=='0')
                                {
                                        printf("\nTen\n");
                                }
                                if(n2=='1')
                                {
                                        printf("\nEleven\n");
                                }
                                if(n2=='2')
                                {
                                        printf("\nTwelve\n");
                                }
                                if(n2=='3')
                                {
                                        printf("\nThirteen\n");
                                }
                                if(n2=='4')
                                {
                                        printf("\nFourteen\n");
                                }
                                if(n2=='5')
                                {
                                        printf("\nFifteen\n");
                                }
                                if(n2=='6')
                                {
                                        printf("\nSixteen\n");
                                }
                                if(n2=='7')
                                {
                                        printf("\nSeventeen\n");
                                }
                                if(n2=='8')
                                {
                                        printf("\nEighteen\n");
                                }
                                if(n2=='9')
                                {
                                        printf("\nNineteen\n");
                                }       
                        } 
                        if(n1=='2')
                        {
                                if(n2=='0')
                                        printf("\nTwenty\n");
                                else
                                {
                                        printf("Twenty %s",num_to_words_ones(n2));
                                }
                                        
                        }
                        if(n1=='3')
                        {
                                if(n2=='0')
                                        printf("\nThirty\n");
                                else
                                {
                                        printf("Thirty %s",num_to_words_ones(n2));
                                }
                                        
                        }
                        if(n1=='4')
                        {
                             if(n2=='0')
                                        printf("\nForty\n");
                               else{
                                  printf("Fourty %s",num_to_words_ones(n2));
                        }
                        }
                                        
                        
                        if(n1=='5')
                        {
                                if(n2=='0')
                                        printf("\nFifty\n");
                                else
                                {
                                        printf("Fifty %s",num_to_words_ones(n2));
                                }                                       
                        }
                        if(n1=='6')
                        {
                                if(n2=='0')
                                        printf("\nSixty\n");
                                else
                                {
                                        printf("Sixty %s",num_to_words_ones(n2));
                                }                                       
                        }
                        if(n1=='7')
                        {
                                if(n2=='0')
                                        printf("\nSeventy\n");
                                else
                                {
                                        printf("\nSeventy %s\n",num_to_words_ones(n2));
                                }                                       
                        }
                        if(n1=='8')
                        {
                                if(n2=='0')
                                        printf("\nEighty\n");
                                else
                                {
                                        printf("\nEighty %s\n",num_to_words_ones(n2));
                                }                                       
                        }
                        if(n1=='9')
                        {
                                if(n2=='0')
                                        printf("\nNinety\n");
                                else
                                {
                                        printf("\nNinety %s\n",num_to_words_ones(n2));
                                }                                       
                        }                       
                }
         } return 0;
  }

